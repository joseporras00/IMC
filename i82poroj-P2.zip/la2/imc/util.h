/*
 * util.h
 *
 *  Created on: 06/03/2015
 *      Author: pedroa
 */

#ifndef UTIL_H_
#define UTIL_H_

namespace util{
int * integerRandomVectorWithoutRepeating(int min, int max, int howMany);

}


#endif /* UTIL_H_ */
