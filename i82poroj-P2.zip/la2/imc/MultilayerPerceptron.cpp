/*********************************************************************
* File  : MultilayerPerceptron.cpp
* Date  : 2020
*********************************************************************/

#include "MultilayerPerceptron.h"

#include "util.h"


#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>  // To establish the seed srand() and generate pseudorandom numbers rand()
#include <limits>
#include <math.h>


using namespace imc;
using namespace std;
using namespace util;

// ------------------------------
// Obtain an integer random number in the range [Low,High]
int randomInt(int Low, int High)
{
	return Low + (rand() % (int)(High - Low + 1));
}

// ------------------------------
// Obtain a real random number in the range [Low,High]
double randomDouble(double Low, double High)
{
	double valor = (double) rand() / RAND_MAX;
	return Low + valor * (High-Low);
}

// ------------------------------
// Constructor: Default values for all the parameters
MultilayerPerceptron::MultilayerPerceptron()
{
	eta=0.7;
	mu=1;	
	validationRatio=0.0;
	decrementFactor=1;
	nOfLayers = 2;
	outputFunction=0;
	online=false;
}

// ------------------------------
// Allocate memory for the data structures
// nl is the number of layers and npl is a vetor containing the number of neurons in every layer
// Give values to Layer* layers
int MultilayerPerceptron::initialize(int nl, int npl[]) {
	nOfLayers=nl;
	layers= new Layer[nOfLayers];
	int i,j=0;

	for(i=0;i<nOfLayers;i++){
		layers[i].nOfNeurons=npl[i];
		layers[i].neurons= new Neuron[layers[i].nOfNeurons];
		if(layers[i].neurons==NULL){
			return -1;
		}		
		
		for(j=0;j<layers[i].nOfNeurons;j++){
			layers[i].neurons[j].out=1.0;
			layers[i].neurons[j].delta=0.0;

			if(i>0){
				int nOfWeights=layers[i-1].nOfNeurons+1;
				layers[i].neurons[j].w=new double[nOfWeights];
				layers[i].neurons[j].deltaW=new double[nOfWeights];
				layers[i].neurons[j].lastDeltaW=new double[nOfWeights];
				layers[i].neurons[j].wCopy=new double[nOfWeights];
				if(layers[i].neurons[j].w==NULL){
					return -1;
				}
			}
		}
	}
	return 1;
	
}


// ------------------------------
// DESTRUCTOR: free memory
MultilayerPerceptron::~MultilayerPerceptron() {
	freeMemory();
}


// ------------------------------
// Free memory for the data structures
void MultilayerPerceptron::freeMemory() {
	for(int i=0;i<nOfLayers;i++){
		for(int j=0;j<layers[i].nOfNeurons;j++){
			if(i>0){
				int nPesos=layers[i-1].nOfNeurons+1;
				for(int k=0;k<nPesos;k++){
					delete[] layers[i].neurons[j].w;
					delete[] layers[i].neurons[j].deltaW;
					delete[] layers[i].neurons[j].lastDeltaW;
					delete[] layers[i].neurons[j].wCopy;
				}
			}
		}
		delete[] layers[i].neurons;
	}
	delete[] layers;
}

// ------------------------------
// Fill all the weights (w) with random numbers between -1 and +1
void MultilayerPerceptron::randomWeights() {
	for(int i=1;i<nOfLayers;i++){
		for(int j=0;j<layers[i].nOfNeurons;j++){
			int nPesos=layers[i-1].nOfNeurons+1;
			for(int k=0;k<nPesos;k++){
				layers[i].neurons[j].w[k]= randomDouble(-1,1);
				
			}
		}
	}
}

// ------------------------------
// Feed the input neurons of the network with a vector passed as an argument
void MultilayerPerceptron::feedInputs(double* input) {
	for(int i=0; i<layers[0].nOfNeurons; i++){		
		layers[0].neurons[i].out = input[i];		
	}
}

// ------------------------------
// Get the outputs predicted by the network (out vector of the output layer) and save them in the vector passed as an argument
void MultilayerPerceptron::getOutputs(double* output)
{
	for(int i=0; i<layers[nOfLayers-1].nOfNeurons; i++){
		output[i] = layers[nOfLayers-1].neurons[i].out;
	}
}

// ------------------------------
// Make a copy of all the weights (copy w in wCopy)
void MultilayerPerceptron::copyWeights() {
	for(int i=0; i<nOfLayers; i++){
		for(int j=0; j<layers[i].nOfNeurons; j++){
			layers[i].neurons[j].wCopy=layers[i].neurons[j].w;
						
		}			
	} 
}

// ------------------------------
// Restore a copy of all the weights (copy wCopy in w)
void MultilayerPerceptron::restoreWeights() {
	for(int i=0; i<nOfLayers; i++){
		for(int j=0; j<layers[i].nOfNeurons; j++){
			layers[i].neurons[j].w=layers[i].neurons[j].wCopy;
			
		}
	}
}

// ------------------------------
// Calculate and propagate the outputs of the neurons, from the first layer until the last one -->-->
void MultilayerPerceptron::forwardPropagate() {
	double out = 0.0,sum=0.0;

	for(int h=1; h<nOfLayers; h++) {
		for(int j=0; j<layers[h].nOfNeurons; j++) {			
			int nPesos=layers[h-1].nOfNeurons;
			for(int k=0;k<nPesos;k++){
				out += layers[h].neurons[j].w[k] * layers[h-1].neurons[k].out;
			}
			out += layers[h].neurons[j].w[nPesos];

			
			if (outputFunction==1 && h==nOfLayers-1){ //softmax
				layers[h].neurons[j].out = exp(out);
				sum += layers[h].neurons[j].out;
			}
			else{	//sigmoide
				layers[h].neurons[j].out = 1 / (1 + exp(-out));
			
			}
			
			out = 0.0;
		}
	}
	if (outputFunction == 1) {
		for(int j=0; j<layers[nOfLayers-1].nOfNeurons; j++)
			layers[nOfLayers-1].neurons[j].out /= sum;
	}
}

// ------------------------------
// Obtain the output error (MSE) of the out vector of the output layer wrt a target vector and return it
// errorFunction=1 => Cross Entropy // errorFunction=0 => MSE
double MultilayerPerceptron::obtainError(double* target, int errorFunction) {
	double error = 0.0;
	if(!errorFunction){
		for(int i=0; i<layers[nOfLayers-1].nOfNeurons; i++){
			error += pow(target[i] - layers[nOfLayers-1].neurons[i].out,2);
		}
	}
	else{
		for(int j=0; j<layers[nOfLayers-1].nOfNeurons; j++){
			error -= target[j] * log(layers[nOfLayers-1].neurons[j].out);
		}
	}	

	return error / layers[nOfLayers-1].nOfNeurons;
}


// ------------------------------
// Backpropagate the output error wrt a vector passed as an argument, from the last layer to the first one <--<--
// errorFunction=1 => Cross Entropy // errorFunction=0 => MSE
void MultilayerPerceptron::backpropagateError(double* target, int errorFunction) {
	// Backpropagate
	if(!outputFunction){
			if(!errorFunction){
				for(int j=0; j<layers[nOfLayers-1].nOfNeurons; j++){
					layers[nOfLayers-1].neurons[j].delta = -(target[j] - layers[nOfLayers-1].neurons[j].out) * layers[nOfLayers-1].neurons[j].out * (1 - layers[nOfLayers-1].neurons[j].out);
				}
			}
			else{
				for(int j=0; j<layers[nOfLayers-1].nOfNeurons; j++){
					layers[nOfLayers-1].neurons[j].delta = -(target[j] / layers[nOfLayers-1].neurons[j].out) * layers[nOfLayers-1].neurons[j].out * (1 - layers[nOfLayers-1].neurons[j].out);
				}
			}
	}
	else{
		double sumatorioSoftmax = 0.0;
		double primerCalculo, segundoCalculo;

		for(int j=0; j<layers[nOfLayers-1].nOfNeurons; j++) {
			for(int i=0; i<layers[nOfLayers-1].nOfNeurons; i++) {
				if (errorFunction){
					primerCalculo = target[i] / layers[nOfLayers-1].neurons[i].out;
				}else{
					primerCalculo = target[i] - layers[nOfLayers-1].neurons[i].out;
				}

				if (i == j){
					segundoCalculo = layers[nOfLayers-1].neurons[j].out * (1 - layers[nOfLayers-1].neurons[i].out);
				}else{
					segundoCalculo = layers[nOfLayers-1].neurons[j].out * (-layers[nOfLayers-1].neurons[i].out);
				}
				sumatorioSoftmax -= primerCalculo * segundoCalculo;
			}
			layers[nOfLayers-1].neurons[j].delta = sumatorioSoftmax;
			sumatorioSoftmax = 0.0;
		}
	}

	double sum = 0.0;
	for(int h=nOfLayers-2; h>0; h--) {
		for(int j=0; j<layers[h].nOfNeurons; j++) {
			for(int i=0; i<layers[h+1].nOfNeurons; i++){
				sum += layers[h+1].neurons[i].w[j] * layers[h+1].neurons[i].delta;
				
			}
			layers[h].neurons[j].delta = sum * layers[h].neurons[j].out * (1 - layers[h].neurons[j].out);
			sum = 0.0;
		}
	}
}

// ------------------------------
// Accumulate the changes produced by one pattern and save them in deltaW
void MultilayerPerceptron::accumulateChange() {
	for(int h=1; h<nOfLayers; h++) {
		for(int j=0; j<layers[h].nOfNeurons; j++) {
			int nPesos=layers[h-1].nOfNeurons;
			for(int k=0;k<nPesos;k++){
				layers[h].neurons[j].deltaW[k] += layers[h].neurons[j].delta * layers[h-1].neurons[k].out;
			}
			layers[h].neurons[j].deltaW[nPesos] += layers[h].neurons[j].delta;
		}
	}
}

// ------------------------------
// Update the network weights, from the first layer to the last one
void MultilayerPerceptron::weightAdjustment() {
	for(int h=1; h<nOfLayers; h++) {
		for(int j=0; j<layers[h].nOfNeurons; j++) {
			int nPesos=layers[h-1].nOfNeurons+1;
			for(int k=0;k<nPesos;k++){
				layers[h].neurons[j].w[k] += -(eta * pow(decrementFactor,-(nOfLayers-h)) * layers[h].neurons[j].deltaW[k]) - (mu * (eta * pow(decrementFactor,-(nOfLayers-h)) * layers[h].neurons[j].lastDeltaW[k]));
				layers[h].neurons[j].lastDeltaW[k] = layers[h].neurons[j].deltaW[k];
			}
			
		}
	}

}

// ------------------------------
// Print the network, i.e. all the weight matrices
void MultilayerPerceptron::printNetwork() {
	int i,j,k;

	for(i=1;i<nOfLayers;i++){
		std::cout << "\nLayer "<<i<<"\n--------"<<endl;
		for(j=0;j<layers[i].nOfNeurons;j++){
			int nOfWeights=layers[i-1].nOfNeurons+1;
			for(k=0;k<nOfWeights;k++){
				std::cout<<layers[i].neurons[j].w[k]<<" ";
			}
			std::cout<<"\n";

		}
	std::cout<<"\n";
	}
}

// ------------------------------
// Perform an epoch: forward propagate the inputs, backpropagate the error and adjust the weights
// input is the input vector of the pattern and target is the desired output vector of the pattern
// The step of adjusting the weights must be performed only in the online case
// If the algorithm is offline, the weightAdjustment must be performed in the "train" function
// errorFunction=1 => Cross Entropy // errorFunction=0 => MSE
void MultilayerPerceptron::performEpoch(double* input, double* target, int errorFunction) {
	feedInputs(input);
	forwardPropagate();
	backpropagateError(target,errorFunction);
	accumulateChange();
	if(online){
		weightAdjustment();
		for(int h=1; h<nOfLayers; h++) {
			for(int j=0; j<layers[h].nOfNeurons; j++) {
				int nPesos=layers[h-1].nOfNeurons+1;
				for(int k=0;k<nPesos;k++){	
					layers[h].neurons[j].deltaW[k] = 0.0;	
							
				}
			}
		}	
	}
}


// ------------------------------
// Read a dataset from a file name and return it
Dataset* MultilayerPerceptron::readData(const char *fileName) {

	ifstream myFile(fileName);    // Create an input stream

    if (!myFile.is_open()) {
       std::cout << "ERROR: I cannot open the file " << fileName << endl;
       return NULL;
    }

	Dataset * dataset = new Dataset;
	if(dataset==NULL)
		return NULL;

	string line;
	int i,j;


	if( myFile.good()) {
		getline(myFile,line);   // Read a line
		istringstream iss(line);
		iss >> dataset->nOfInputs;
		iss >> dataset->nOfOutputs;
		iss >> dataset->nOfPatterns;
	}
	dataset->inputs = new double*[dataset->nOfPatterns];
	dataset->outputs = new double*[dataset->nOfPatterns];

	for(i=0; i<dataset->nOfPatterns; i++){
		dataset->inputs[i] = new double[dataset->nOfInputs];
		dataset->outputs[i] = new double[dataset->nOfOutputs];
	}

	i=0;
	while ( myFile.good()) {
		getline(myFile,line);   // Read a line
		if (! line.empty()) {
			istringstream iss(line);
			for(j=0; j< dataset->nOfInputs; j++){
				double value;
				iss >> value;
				if(!iss)
					return NULL;
				dataset->inputs[i][j] = value;
			}
			for(j=0; j< dataset->nOfOutputs; j++){
				double value;
				iss >> value;
				if(!iss)
					return NULL;
				dataset->outputs[i][j] = value;
			}
			i++;
		}
	}

	myFile.close();

	return dataset;
}


// ------------------------------
// Train the network for a dataset (one iteration of the external loop)
// errorFunction=1 => Cross Entropy // errorFunction=0 => MSE
void MultilayerPerceptron::train(Dataset* trainDataset, int errorFunction) {
	for(int h=1; h<nOfLayers; h++) {
		for(int j=0; j<layers[h].nOfNeurons; j++) {
			int nPesos=layers[h-1].nOfNeurons+1;
			for(int k=0;k<nPesos;k++){	
				layers[h].neurons[j].deltaW[k] = 0.0;	
						
			}
		}
	}	
	for(int i=0; i<trainDataset->nOfPatterns; i++)
		performEpoch(trainDataset->inputs[i], trainDataset->outputs[i], errorFunction);

	if (!online)
		weightAdjustment();
}

// ------------------------------
// Test the network with a dataset and return the error
// errorFunction=1 => Cross Entropy // errorFunction=0 => MSE
double MultilayerPerceptron::test(Dataset* dataset, int errorFunction) {
	double error = 0;
	for(int i=0; i<dataset->nOfPatterns; i++) {
		feedInputs(dataset->inputs[i]);
		forwardPropagate();
		error += obtainError(dataset->outputs[i],errorFunction);
	}
	error /= dataset->nOfPatterns;
	return error;
}


// ------------------------------
// Test the network with a dataset and return the CCR
double MultilayerPerceptron::testClassification(Dataset* dataset) {
	double CCR = 0.0;
	int** matrizConfusion;
	matrizConfusion= new int*[dataset->nOfOutputs];
	for(int i=0;i<dataset->nOfOutputs;i++){
		matrizConfusion[i]=new int[dataset->nOfOutputs];
	}

	for(int i=0;i<dataset->nOfOutputs;i++){
		for(int j=0;j<dataset->nOfOutputs;j++){
			matrizConfusion[i][j]=0;
		}
	}


	for(int i=0; i<dataset->nOfPatterns; i++) {
		feedInputs(dataset->inputs[i]);
		forwardPropagate();

		int indiceDeseado = 0;
        int indiceObtenido = 0;
        double valorMaxObtenido = 0.0;

        for(int j=0; j<layers[nOfLayers-1].nOfNeurons; j++) {
			if(dataset->outputs[i][j] == 1){
                indiceDeseado = j;
			}

            if(layers[nOfLayers-1].neurons[j].out > valorMaxObtenido) {
            	valorMaxObtenido = layers[nOfLayers-1].neurons[j].out;
                indiceObtenido = j;
            }
        }

        matrizConfusion[indiceDeseado][indiceObtenido]++;

        if(indiceDeseado == indiceObtenido){
            CCR++;
		}
    }

	for(int i=0; i<dataset->nOfOutputs; i++) {
		std::cout << "|";
		for(int j=0; j<dataset->nOfOutputs; j++)
			std::cout << " " << matrizConfusion[i][j];
		std::cout << " |" << std::endl;
	}


	return 100 * (CCR / dataset->nOfPatterns);
}


// ------------------------------
// Optional Kaggle: Obtain the predicted outputs for a dataset
void MultilayerPerceptron::predict(Dataset* dataset)
{
	int i;
	int j;
	int numSalidas = layers[nOfLayers-1].nOfNeurons;
	double * salidas = new double[numSalidas];
	
	std::cout << "Id,Category" << endl;
	
	for (i=0; i<dataset->nOfPatterns; i++){

		feedInputs(dataset->inputs[i]);
		forwardPropagate();
		getOutputs(salidas);

		int maxIndex = 0;
		for (j = 0; j < numSalidas; j++)
			if (salidas[j] >= salidas[maxIndex])
				maxIndex = j;
		
		std::cout << i << "," << maxIndex << endl;

	}
}



// ------------------------------
// Run the traning algorithm for a given number of epochs, using trainDataset
// Once finished, check the performance of the network in testDataset
// Both training and test MSEs should be obtained and stored in errorTrain and errorTest
// Both training and test CCRs should be obtained and stored in ccrTrain and ccrTest
// errorFunction=1 => Cross Entropy // errorFunction=0 => MSE
void MultilayerPerceptron::runBackPropagation(Dataset * trainDataset, Dataset * testDataset, int maxiter, double *errorTrain, double *errorTest, double *ccrTrain, double *ccrTest, int errorFunction)
{
	int countTrain = 0;

	// Random assignment of weights (starting point)
	randomWeights();

	double minTrainError = 0;
	int iterWithoutImproving = 0;
	nOfTrainingPatterns = trainDataset->nOfPatterns;

	Dataset * validationDataset = NULL;
	double validationError = 0, previousValidationError = 0;
	int iterWithoutImprovingValidation = 0;

	// Generate validation data
	if(validationRatio > 0 && validationRatio < 1){
		// ....
	}

	// Learning
	do {

		train(trainDataset,errorFunction);

		double trainError = test(trainDataset,errorFunction);
		if(countTrain==0 || trainError < minTrainError){
			minTrainError = trainError;
			copyWeights();
			iterWithoutImproving = 0;
		}
		else if( (trainError-minTrainError) < 0.00001)
			iterWithoutImproving = 0;
		else
			iterWithoutImproving++;

		if(iterWithoutImproving==50){
			std::cout << "We exit because the training is not improving!!"<< endl;
			restoreWeights();
			countTrain = maxiter;
		}

		countTrain++;

		if(validationDataset!=NULL){
			if(previousValidationError==0)
				previousValidationError = 999999999.9999999999;
			else
				previousValidationError = validationError;
			validationError = test(validationDataset,errorFunction);
			if(validationError < previousValidationError)
				iterWithoutImprovingValidation = 0;
			else if((validationError-previousValidationError) < 0.00001)
				iterWithoutImprovingValidation = 0;
			else
				iterWithoutImprovingValidation++;
			if(iterWithoutImprovingValidation==50){
				std::cout << "We exit because validation is not improving!!"<< endl;
				restoreWeights();
				countTrain = maxiter;
			}
		}

		std::cout << "Iteration " << countTrain << "\t Training error: " << trainError << "\t Validation error: " << validationError << endl;

	} while ( countTrain<maxiter );

	if ( (iterWithoutImprovingValidation!=50) && (iterWithoutImproving!=50))
		restoreWeights();

	std::cout << "NETWORK WEIGHTS" << endl;
	std::cout << "===============" << endl;
	printNetwork();

	std::cout << "Desired output Vs Obtained output (test)" << endl;
	std::cout << "=========================================" << endl;
	for(int i=0; i<testDataset->nOfPatterns; i++){
		double* prediction = new double[testDataset->nOfOutputs];

		// Feed the inputs and propagate the values
		feedInputs(testDataset->inputs[i]);
		forwardPropagate();
		getOutputs(prediction);
		for(int j=0; j<testDataset->nOfOutputs; j++)
			std::cout << testDataset->outputs[i][j] << " -- " << prediction[j] << " ";
		std::cout << endl;
		delete[] prediction;

	}

	*errorTest=test(testDataset,errorFunction);;
	*errorTrain=minTrainError;
	*ccrTest = testClassification(testDataset);
	*ccrTrain = testClassification(trainDataset);

}

// -------------------------
// Optional Kaggle: Save the model weights in a textfile
bool MultilayerPerceptron::saveWeights(const char * fileName)
{
	// Object for writing the file
	ofstream f(fileName);

	if(!f.is_open())
		return false;

	// Write the number of layers and the number of layers in every layer
	f << nOfLayers;

	for(int i = 0; i < nOfLayers; i++)
	{
		f << " " << layers[i].nOfNeurons;
	}
	f << " " << outputFunction;
	f << endl;

	// Write the weight matrix of every layer
	for(int i = 1; i < nOfLayers; i++)
		for(int j = 0; j < layers[i].nOfNeurons; j++)
			for(int k = 0; k < layers[i-1].nOfNeurons + 1; k++)
				if(layers[i].neurons[j].w!=NULL)
				    f << layers[i].neurons[j].w[k] << " ";

	f.close();

	return true;

}


// -----------------------
// Optional Kaggle: Load the model weights from a textfile
bool MultilayerPerceptron::readWeights(const char * fileName)
{
	// Object for reading a file
	ifstream f(fileName);

	if(!f.is_open())
		return false;

	// Number of layers and number of neurons in every layer
	int nl;
	int *npl;

	// Read number of layers
	f >> nl;

	npl = new int[nl];

	// Read number of neurons in every layer
	for(int i = 0; i < nl; i++)
	{
		f >> npl[i];
	}
	f >> outputFunction;

	// Initialize vectors and data structures
	initialize(nl, npl);

	// Read weights
	for(int i = 1; i < nOfLayers; i++)
		for(int j = 0; j < layers[i].nOfNeurons; j++)
			for(int k = 0; k < layers[i-1].nOfNeurons + 1; k++)
				if(!(outputFunction==1 && (i==(nOfLayers-1)) && (k==(layers[i].nOfNeurons-1))))
					f >> layers[i].neurons[j].w[k];

	f.close();
	delete[] npl;

	return true;
}
